CREATE DATABASE ToysGroupDB

/* Creo il database relativo a ToysGroup*/

USE ToysGroupDB

/* Attraverso il comando USE specifico di utilizzare il database ToysGroupDB*/

CREATE TABLE Products
(
ProductID tinyint NOT NULL,
ProductName VARCHAR(30),
CategoryID smallint,
CategoryName VARCHAR(30))

/* Creo la tabella relativa ai prodotti*/

CREATE TABLE Sales
(
SalesOrderNumber VARCHAR(10) NOT NULL,
SalesOrderLineNumber tinyint NOT NULL,
ProductID tinyint,
CountryID tinyint,
OrderDate date,
PayDate date,
ShipDate date,
UnitPrice decimal(10,2),
OrderQty tinyint,
SalesAmount AS UnitPrice*OrderQty)

/* Creo la tabella relativa ai prodotti*/

CREATE TABLE Region
(
CountryID tinyint NOT NULL,
CountryName VARCHAR(30),
RegionID tinyint,
RegionName VARCHAR(30))

/* Creo la tabella relativa ai prodotti*/

/* Ora aggiungo i vari contraint relativi alle varie chiavi */
/* In primo luogo definisco le chiavi primarie delle varie tabelle */

ALTER TABLE Products
ADD CONSTRAINT PK_Products PRIMARY KEY (ProductID)

ALTER TABLE Sales
ADD CONSTRAINT PK_Sales PRIMARY KEY (SalesOrderNumber, SalesOrderLineNumber)

ALTER TABLE Region
ADD CONSTRAINT PK_Region PRIMARY KEY (CountryID)

/* Ora definisco le chiavi esterne */

ALTER TABLE Sales
ADD CONSTRAINT FK_Products_Sales FOREIGN KEY (ProductID)
REFERENCES Products(ProductID);

ALTER TABLE Sales
ADD CONSTRAINT FK_Region_Sales FOREIGN KEY (CountryID)
REFERENCES Region(CountryID);

/* I dati sono stati inseriti mediante importazione di file .csv, presenti nella cartegna di consegna dell'elaborato */

