--1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l�univocit� dei valori di ciascuna PK (una query per tabella implementata).

SELECT COUNT(*), Region.CountryID
FROM Region
GROUP BY Region.CountryID
HAVING COUNT(*) > 1

SELECT COUNT(*), Sales.SalesOrderNumber, Sales.SalesOrderLineNumber
FROM Sales
GROUP BY Sales.SalesOrderNumber, Sales.SalesOrderLineNumber
HAVING COUNT(*) > 1

SELECT COUNT(*), Products.ProductID
FROM Products
GROUP BY Products.ProductID
HAVING COUNT(*) > 1

--2) Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, 
-- il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati pi� di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT CONCAT(s.SalesOrderNumber, '-', s.SalesOrderLineNumber) AS DocumentCode, 
	   p.ProductName, p.CategoryName, 
	   r.CountryName, r.RegionName,
	   YEAR(s.OrderDate)*10000 + MONTH(s.OrderDate)*100 + DAY(s.OrderDate) AS OrderDate,
	   CASE
			WHEN DATEDIFF(DAY, s.orderdate, GETDATE()) > 180 THEN 0
			ELSE 1 END AS DataCheck
FROM Sales AS s
JOIN Products AS p ON s.ProductID=p.ProductID
JOIN Region AS r ON s.CountryID=r.CountryID

--3) Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT p.ProductName, SUM(s.SalesAmount) AS TotSales
FROM Sales AS s
JOIN Products AS p ON s.ProductID=p.ProductID
GROUP BY p.ProductName

--4) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT r.CountryName, SUM(s.SalesAmount) AS TotSales
FROM Sales AS s
JOIN Region AS r ON r.CountryID=s.CountryID
GROUP BY r.CountryName

--5) Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?

SELECT TOP 1 p.CategoryName AS Category, SUM(s.OrderQty) As Selled
FROM Sales AS s
JOIN Products AS p ON s.ProductID=p.ProductID
GROUP BY p.CategoryName
ORDER BY Category DESC

-- Risposta: la categoria pi� venduta, con un totale di 25 prodotti venduti, � la categoria Toys

--6) Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

-- Metodo 1): Join con condizione WHERE

SELECT p.ProductName, s.OrderQty
FROM Sales AS s
RIGHT JOIN Products AS p ON s.ProductID = p.ProductID
WHERE OrderQty IS NULL

-- Metodo 1): SubQuery

SELECT ProductName
FROM Products
Where ProductID NOT IN 
(
	SELECT ProductID
	FROM Sales 
	WHERE OrderQty > 0
)

--7)	Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).

SELECT p.ProductName, LastDate.OrderDate
FROM (
	SELECT s1.ProductID, s1.OrderDate
	FROM Sales as s1
	WHERE OrderDate = (
				SELECT MAX(OrderDate)
				FROM Sales as s2
				where s1.ProductID=s2.ProductID)
	Group by s1.ProductID, s1.OrderDate) AS LastDate
JOIN Products AS p ON LastDate.ProductID=p.ProductID
ORDER BY LastDate.OrderDate DESC

--8) Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
CREATE VIEW Product_data_info
AS (
SELECT p.ProductName, p.CategoryName,
	   s.UnitPrice
FROM Sales AS s
JOIN Products AS p ON s.ProductID=p.ProductID
JOIN Region AS r on s.CountryID=r.CountryID)


--9) Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche
CREATE VIEW Product_geography_sales_info
AS (
SELECT p.ProductName, p.CategoryName, 
	   CONCAT(s.SalesOrderNumber, '-', s.SalesOrderLineNumber) AS DocumentCode,
	   r.CountryName, r.RegionName
FROM Sales AS s
JOIN Products AS p ON s.ProductID=p.ProductID
JOIN Region AS r on s.CountryID=r.CountryID)

--10) ottenute le viste per la costruzione delle dimensioni di analisi prodotto (punto 7) e area geografica (punto 8), 
-- implementa un modello logico in Power Query e costruisci un report per l�analisi delle vendite

CREATE VIEW Product_Sales
AS (
SELECT p.ProductName, p.CategoryName, 
	   s.SalesOrderNumber, s.SalesOrderLineNumber, s.SalesAmount,
	   r.CountryName, r.RegionName
FROM Sales AS s
JOIN Products AS p ON s.ProductID=p.ProductID
JOIN Region AS r on s.CountryID=r.CountryID)









